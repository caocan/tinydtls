var searchData=
[
  ['session_5ft',['session_t',['../structsession__t.html',1,'']]]
];
