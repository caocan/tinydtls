var searchData=
[
  ['r_5fkey_5foffset',['R_KEY_OFFSET',['../dtls_8c.html#ab7a17e13b17da97cbef046b20cd7280f',1,'dtls.c']]],
  ['random',['random',['../structdtls__handshake__parameters__t.html#a5c4e7bb5d4d890200a176cfe13c6fb9a',1,'dtls_handshake_parameters_t']]],
  ['read',['read',['../structdtls__handler__t.html#a48f28d381286b493fe6dd8eab5cbaa88',1,'dtls_handler_t']]],
  ['readbuf',['readbuf',['../structdtls__context__t.html#ad6facbcd3c19ac8e1c79b1664dcf2434',1,'dtls_context_t']]],
  ['retransmit_5fcnt',['retransmit_cnt',['../structnetq__t.html#aacd03017f40248c2f48c2b7b9cd92dc8',1,'netq_t']]],
  ['role',['role',['../structdtls__peer__t.html#aeca80f1bcbcfdba89a2ab08e4bc48120',1,'dtls_peer_t']]],
  ['rseq',['rseq',['../structdtls__security__parameters__t.html#a100dc82ee41004df1d9f211873332f87',1,'dtls_security_parameters_t']]]
];
